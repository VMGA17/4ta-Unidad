/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;
import java.util.Scanner;

/**
 *
 * @author estudiante
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int A;
        int B;
        
        System.out.println("Ingrese primer valor");
        Scanner D1 = new Scanner(System.in);
        A = D1.nextInt();
        
        System.out.println("Ingrese segundo valor");
        Scanner D2 = new Scanner(System.in);
        B = D2.nextInt();
        
        System.out.println("El primer valor"+ A);
        System.out.println("El segundo valor"+ B);
    }
    
}
